java -Djava.ext.dirs="./lib" -jar "./lib/bs-tool-cgt-1.4.jar"
