java -Djava.ext.dirs="./lib:./lib/jodconverter" -jar "./lib/common_gui_tools-1.2.jar"
